#!/usr/bin/env python
# encoding: utf-8
"""
# @Time    : 2021/10/24 3:07 下午
# @Author  : pangliangliang
# @Project : PycharmProjects
# @File    : send_message.py
# @Software: PyCharm
"""


def send():
    print("10086正在发送短信...")
