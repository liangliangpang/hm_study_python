#!/usr/bin/env python
# encoding: utf-8
"""
# @Time    : 2021/10/24 3:07 下午
# @Author  : pangliangliang
# @Project : PycharmProjects
# @File    : receive_message.py
# @Software: PyCharm
"""


def receive():
    return "这是来自10086的短信"
